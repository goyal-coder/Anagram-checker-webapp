function checkAnagram(){
firstWord=document.getElementById("word1").value 
secondWord=document.getElementById("word2").value
if(firstWord.length!=secondWord.length){
    document.getElementById("result").innerHTML="Not Anagrams"
    return false}
else{
    let firstWordArray=firstWord.split("").sort()
    let secondWordArray=secondWord.split("").sort()
    for(let i=0;i<firstWordArray.length;i++){
        if(firstWordArray[i]!=secondWordArray[i]){
            document.getElementById("result").innerHTML="Not Anagrams"
            return false
        }
    }
    document.getElementById("result").innerHTML="Anagrams"
    return true}
}